//
//  Loader.swift
//  NewsFeedAssignment
//
//  Created by Sachin Mann on 21/08/19.
//  Copyright © 2019 Sachin Mann. All rights reserved.
//

import Foundation
import NVActivityIndicatorView
/** **Loader** used for showing loader(**NVActivityIndicatorPresenter**)
 **/
class Loader{
    /** it starts loader automatically will stop after 5 sec if not get stopped
     **/
    class func startAnimating() {
        let size = CGSize(width: 60.0, height: 50.0)
        let avtivityData = ActivityData(size: size,message: nil, type: NVActivityIndicatorType(rawValue: 17), color:  #colorLiteral(red: 0, green: 0, blue: 0, alpha: 0.75), backgroundColor :  #colorLiteral(red: 0, green: 0, blue: 0, alpha: 0) , textColor:  #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0))
        NVActivityIndicatorPresenter.sharedInstance.startAnimating(avtivityData)
        DispatchQueue.main.asyncAfter(deadline: .now() + 5) {
            NVActivityIndicatorPresenter.sharedInstance.stopAnimating()
        }
    }
    /** it will stop loader
     **/
    class func stopAnimation(){
        NVActivityIndicatorPresenter.sharedInstance.stopAnimating()
    }
}
