//
//  shadowView.swift
//  NewsFeedAssignment
//
//  Created by CE0009118 on 22/08/19.
//  Copyright © 2019 CE0009118. All rights reserved.
//


import UIKit

//@IBDesignable
//class ShadowView: UIView {
//    @IBInspectable var shadowColorr: UIColor = UIColor.black {
//        didSet {
//            self.updateView()
//        }
//    }
//    @IBInspectable var shadowOpacityy: Float = 0.5 {
//        didSet {
//            self.updateView()
//        }
//    }
//    @IBInspectable var shadowOffsett: CGSize = CGSize(width: 3, height: 3) {
//        didSet {
//            self.updateView()
//        }
//    }
//    @IBInspectable var shadowRadiuss: CGFloat = 15.0 {
//        didSet {
//            self.updateView()
//        }
//    }
//
//    //Apply params
//    func updateView() {
//        self.layer.shadowColor = self.shadowColorr.cgColor
//        self.layer.shadowOpacity = self.shadowOpacityy
//        self.layer.shadowOffset = self.shadowOffsett
//        self.layer.shadowRadius = self.shadowRadiuss
//    }
//}
