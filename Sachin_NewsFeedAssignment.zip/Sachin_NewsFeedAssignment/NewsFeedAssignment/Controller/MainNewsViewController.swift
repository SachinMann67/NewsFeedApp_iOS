//
//  MainNewsViewController.swift
//  NewsFeedAssignment
//
//  Created by Sachin Mann on 19/08/19.
//  Copyright © 2019 Sachin Mann. All rights reserved.
//

import UIKit
import Moya
import AlamofireImage

// MARK:----
/** for **Top-Headlines** Api of news is used and taking parameters of country and category, showing 4 pageSize result and having pagination implemented which will give u result in batch of 4 pageSize till u reached to totalPages
 **/
class MainNewsViewController: UIViewController {
    
    /** **newsMoyaProvider** Provider for **NewsNetworkServices** **/
    let newsMoyaProvider = MoyaProvider<NewsNetworkServices>()
    
    /** **newsArticlesDataModel** Model for **News Articles** **/
    var newsArticlesDataModel = [Articles]()
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var searchBar: UISearchBar!
    var totalPages : Int?
    var currentPageNumber = 1
    var choosedCountry = String() //choosed country by user
    var choosedCategory = String() // choosed category by user
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
        tableView.tableFooterView = UIView() // to remove extra cells
        navigationItem.rightBarButtonItem = UIBarButtonItem(image: UIImage(named: "searchIcon"), style: .plain, target: self, action: #selector(searchTapped))
        navigationController?.navigationBar.tintColor = #colorLiteral(red: 0.8470588235, green: 0.1960784314, blue: 0.2352941176, alpha: 1)
        navigationController?.navigationBar.topItem?.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: self, action: nil)
        self.title = "Top News"
        Loader.startAnimating()
        newsApicall(country: choosedCountry, category: choosedCategory, page: currentPageNumber)
    }

    /** Func will instantiate **SearchViewController** on the tap of search icon **/
    @objc func searchTapped(){
        print("search Tapped")
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let controller = storyboard.instantiateViewController(withIdentifier: "SearchViewController") as! NewsSearchViewController
        self.navigationController?.pushViewController(controller, animated: true)
    }
}

// MARK: extension for Tableview delegates

extension MainNewsViewController: UITableViewDataSource,UITableViewDelegate{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return newsArticlesDataModel.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let index = indexPath.row
        let cell : MainNewsVCTableViewCell = tableView.dequeueReusableCell(withIdentifier: "newsCells", for: indexPath) as! MainNewsVCTableViewCell
        cell.newsTitleLbl.text = newsArticlesDataModel[index].title
        cell.newsDescLbl.text = newsArticlesDataModel[index].description
        cell.contentLbl.text = newsArticlesDataModel[index].content
        if let string = newsArticlesDataModel[index].publishedAt{
            if let range = string.range(of: "T") {
                let subStr = string[string.startIndex..<range.lowerBound]
                var datee = [String]()
                datee.append(String(subStr))
                cell.publishedAt.text = datee[0]
            }
        }
        cell.authorNameLbl.text = newsArticlesDataModel[index].author
        if let imageUrl = newsArticlesDataModel[index].urlToImage{
            if let url = URL(string: imageUrl){
               cell.newsImageView.af_setImage(withURL: url)
            }
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 500
    }
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        /** Pagination **/
        if indexPath.row == newsArticlesDataModel.count - 1{
            if let totalPagesObj = totalPages{
                if currentPageNumber < totalPagesObj{
                    currentPageNumber = currentPageNumber + 1
                    newsApicall(country: choosedCountry, category: choosedCategory, page: currentPageNumber)
                }
            }
        }
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print(indexPath.row)
        let index = indexPath.row
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let controller = storyboard.instantiateViewController(withIdentifier: "SourceNewsWebViewController") as! SourceNewsWebViewController
        if let newsUrl = newsArticlesDataModel[index].url{
        controller.url = newsUrl
        }
        self.navigationController?.pushViewController(controller, animated: true)
    }
    
}

// MARK: extension for Api's

extension MainNewsViewController{
    /**
     - Api is for getting all news related to country and category
     - Parameters :
        - page : no of page result u need **Pagination**
        - country : name of country
        - category : choosed category (entertainment,business etc.)
     **/
    func newsApicall(country : String, category : String , page : Int){
        newsMoyaProvider.request(.getNews(country: country, category: category, page: page)) { (result) in
            print(result)
            switch result{
            case .success(let response):
                print(response)
                do {
                    let newsData = try JSONDecoder().decode(NewsDataModel.self, from: response.data)
                    print(newsData)
                    if let newsArticleData = newsData.articles{
                        for i in 0..<newsArticleData.count{
                            self.newsArticlesDataModel.append(newsArticleData[i])
                        }
                    }
                    self.totalPages = newsData.totalResults
                    DispatchQueue.main.async {
                        self.tableView.reloadData()
                        Loader.stopAnimation()

                    }
                }catch{
                    print(error.localizedDescription)
                    Loader.stopAnimation()

                }
            case .failure(let error):
                print(error)
                Loader.stopAnimation()

            }
        }
    }
}
