//
//  ViewController.swift
//  NewsFeedAssignment
//
//  Created by CE0009118 on 19/08/19.
//  Copyright © 2019 CE0009118. All rights reserved.
//

import UIKit

class UserChoiceViewController: UIViewController {
    @IBOutlet weak var choosedNewsCategory: UISegmentedControl!
    @IBOutlet weak var choosedCountry: UISegmentedControl!
    @IBOutlet weak var nextButton: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    @IBAction func nextButtonPressed(_ sender: Any) {
        if let selectedCountry = choosedCountry.titleForSegment(at: choosedCountry.selectedSegmentIndex), let selectedCategory = choosedNewsCategory.titleForSegment(at: choosedNewsCategory.selectedSegmentIndex){
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let controller = storyboard.instantiateViewController(withIdentifier: "MainNewsViewController") as! MainNewsViewController
            controller.choosedCountry = selectedCountry
            controller.choosedCategory = selectedCategory
            self.navigationController?.pushViewController(controller, animated: true)
        }
    }
    
}

