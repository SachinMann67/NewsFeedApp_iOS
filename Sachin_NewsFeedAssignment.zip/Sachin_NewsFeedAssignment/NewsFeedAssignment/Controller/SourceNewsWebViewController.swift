//
//  SourceNewsWebViewController.swift
//  NewsFeedAssignment
//
//  Created by Sachin Mann on 21/08/19.
//  Copyright © 2019 Sachin Mann. All rights reserved.
//

import UIKit
import WebKit
import NVActivityIndicatorView


class SourceNewsWebViewController: UIViewController {
    var url = String()
    @IBOutlet weak var newsWebView: WKWebView!
    override func viewDidLoad() {
        super.viewDidLoad()
        setGUIScreen(url: url)
        newsWebView.navigationDelegate = self
        navigationController?.navigationBar.topItem?.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: self, action: nil)
        self.title = "News"
    }

}
// MARK: extension containing functions **setGUIScreen** and **setGUIScreen**
extension SourceNewsWebViewController{
    /** **setGUIScreen** used for GUIScreen
     -parameters :
        -url : selected news url by user
     **/
    func setGUIScreen(url: String) {
        Loader.startAnimating()
        if let webUrl: NSURL = NSURL(string: url){
            let webRequest: NSURLRequest = NSURLRequest(url: webUrl as URL)
            newsWebView.load(webRequest as URLRequest)
        }
    }
}
// MARK: extension for delegates of **WKNavigationDelegate**

extension SourceNewsWebViewController: WKNavigationDelegate {
    
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        Loader.stopAnimation()
    }
    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
        if NVActivityIndicatorPresenter.sharedInstance.isAnimating == true {
            Loader.stopAnimation()
        }
        let alert = UIAlertController(title: "Sorry!", message: "There might be an technical or internet issue", preferredStyle: .alert)
        let okAction = UIAlertAction(title: "Ok", style: .default, handler: { alert -> Void in
            self.navigationController?.popToRootViewController(animated: true)
        })
        alert.addAction(okAction)
        self.present(alert, animated: true, completion: nil)
    }
}
