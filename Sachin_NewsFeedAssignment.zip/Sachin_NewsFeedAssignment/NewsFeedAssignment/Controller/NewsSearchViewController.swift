//
//  ViewController.swift
//  searchBar
//
//  Created by Sachin Mann on 19/08/19.
//  Copyright © 2019 Sachin Mann. All rights reserved.
//

import UIKit
import Material
import Moya

// MARK:----
/** for search **Everything** Api of news is used , for the searched character i am showing maximum of 10 pageSize(news)
 **/
class NewsSearchViewController: UIViewController {
    
    /** **newsMoyaProvider** Provider for **NewsNetworkServices** used in search**/
    let newsMoyaProvider = MoyaProvider<NewsNetworkServices>()
    
    /** **newsArticlesDataModel** Model for **News Articles** during search **/
    var newsArticlesDataModel = [Articles]()
    var totalPages : Int?
    var currentPageNumber = 1
    var searchedText = ""
    @IBOutlet weak var searchCard: Card!
    @IBOutlet weak var tableView: UITableView!
    fileprivate var toolbar: Toolbar!
    let close  = UIButton(type: .custom)
    fileprivate var searchBar: SearchBar!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
        tableView.tableFooterView = UIView() // to remove extra cells
        prepareSearch()
    }
    override func viewWillAppear(_ animated: Bool) {
        navigationController?.setNavigationBarHidden(true, animated: animated)
    }
    override func viewWillDisappear(_ animated: Bool) {
        navigationController?.setNavigationBarHidden(false, animated: animated)
    }
    
    /**
     func is to remove text which is write by user in searchBar on the click of cross Button came in searchBar
     **/
    @objc func handleCloseButton() {
        if searchBar.textField.text?.count != 0 {
            searchBar.textField.text = ""
            close.isHidden = true
        }
    }
    /**
     func called on the click of backbutton basically for popping viewcontroller
     **/
    @objc func handleBackButton()  {
        print("back button pressed")
        self.navigationController?.popViewController(animated: true)
    }
}

// MARK: extension for Preparing Search
extension NewsSearchViewController{
    /**
     **prepareSearch** func is to create searchBar and its UI
     - called in viewdidload
     **/
    func prepareSearch(){
        searchBar = SearchBar()
        searchBar.placeholder = " Search "
        searchBar.placeholderColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 0.5305811216)
        searchBar.textColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1)
        searchBar.tintColor = #colorLiteral(red: 0.8470588235, green: 0.1960784314, blue: 0.2352941176, alpha: 1)
        searchBar.delegate = self
        searchBar.clearButton.isHidden = true
        searchBar.textField.delegate = self
        searchBar.textField.returnKeyType = UIReturnKeyType.search
        searchBar.textField.backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        searchBar.backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        if let closeBtn = UIImage(named:"om-close-btn"){
            close.setImage(closeBtn, for: .normal)
            close.isHidden = true
            close.frame = CGRect(x: 0, y: 0, width: 24, height: 24)
            close.addTarget(self, action: #selector(handleCloseButton), for: UIControl.Event.touchUpInside)
            searchBar.textField.rightView = close
            let backButtonn: IconButton = IconButton(image: UIImage(named: "om-back"), tintColor: #colorLiteral(red: 0.8470588235, green: 0.1960784314, blue: 0.2352941176, alpha: 1))
            backButtonn.addTarget(self, action: #selector(handleBackButton), for: UIControl.Event.touchUpInside)
            searchBar.textField.leftView = backButtonn
            searchBar.textField.leftViewMode = UITextField.ViewMode.always
            searchBar.textField.leftViewMode = .always
            searchBar.textField.rightViewMode = UITextField.ViewMode.always
            searchBar.textField.rightViewMode = .always
            searchBar.textField.becomeFirstResponder()
            toolbar = Toolbar()
            toolbar.centerViews = [searchBar]
            toolbar.backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
            searchCard.contentView = toolbar
            searchCard.backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
            searchCard.layer.cornerRadius = 10.0
            searchCard.layer.borderWidth = 1
            searchCard.layer.borderColor = #colorLiteral(red: 0.8470588235, green: 0.1960784314, blue: 0.2352941176, alpha: 1)
            searchCard.contentViewEdgeInsets = EdgeInsets.init(top: 0, left: 0, bottom: 2, right: 0)
            view.bringSubviewToFront(searchCard)
        }
    }
}

// MARK: extension for TableView Delegates
extension NewsSearchViewController : UITableViewDelegate , UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return newsArticlesDataModel.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let index = indexPath.row
        let cell : SearchResultTableViewCell = tableView.dequeueReusableCell(withIdentifier: "SearchResultTableViewCell", for: indexPath) as! SearchResultTableViewCell
        cell.titleLbl.text = newsArticlesDataModel[index].title
        cell.descLbl.text = newsArticlesDataModel[index].description
        cell.contentLbl.text = newsArticlesDataModel[index].content
        if let string = newsArticlesDataModel[index].publishedAt{
            if let range = string.range(of: "T") {
                let subStr = string[string.startIndex..<range.lowerBound]
                var datee = [String]()
                datee.append(String(subStr))
                cell.publishedAtLbl.text = datee[0]
            }
        }
        cell.authorNameLbl.text = newsArticlesDataModel[index].author
        if let imageUrl = newsArticlesDataModel[index].urlToImage{
            if let url = URL(string: imageUrl){
                cell.newsImageView.af_setImage(withURL: url)
            }
        }
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 500
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print(indexPath.row)
        let index = indexPath.row
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let controller = storyboard.instantiateViewController(withIdentifier: "SourceNewsWebViewController") as! SourceNewsWebViewController
        if let newsUrl = newsArticlesDataModel[index].url{
            controller.url = newsUrl
        }
        self.navigationController?.pushViewController(controller, animated: true)
    }
}

// MARK: extension SearchBar Delegates
extension NewsSearchViewController: SearchBarDelegate ,UITextFieldDelegate{
    func searchBar(searchBar: SearchBar, didChange textField: UITextField, with text: String?) {
        if textField.text == ""{
            close.isHidden = true
        }else{
            close.isHidden = false
        }
        //delete data and api call again
        print("call api \(String(describing: text))")
        if let searchText = text{
            searchedText = searchText
            searchApiCall(character: searchText, page: currentPageNumber)
        }
    }
}

// MARK: extension for Api's
extension NewsSearchViewController{
    /**
     - Api is for getting all news related to what user searched and it will give 10 results only
     - Parameters :
        - page : no of page result u need (statically it is set to 1 only)
        - character : text or characters searched by User
     **/
    func searchApiCall(character : String, page: Int) {
        Loader.startAnimating()
        newsMoyaProvider.request(.searchNews(q: character, page: page)) { (result) in
            print(result)
            switch result{
            case .success(let response):
                print(response)
                do {
                    let searchResultData = try JSONDecoder().decode(NewsDataModel.self, from: response.data)
                    print(searchResultData)
                    if let newsArticleData = searchResultData.articles{
                        self.newsArticlesDataModel = newsArticleData
                    }
                    DispatchQueue.main.async {
                        self.tableView.reloadData()
                        Loader.stopAnimation()
                    }
                }catch {
                    print(error.localizedDescription)
                    Loader.stopAnimation()
                }
            case .failure(let error):
                print(error)
                Loader.stopAnimation()
            }
        }
    }
}
