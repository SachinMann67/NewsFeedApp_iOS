//
//  NewsNetworkServices.swift
//  NewsFeedAssignment
//
//  Created by Sachin Mann on 19/08/19.
//  Copyright © 2019 Sachin Mann. All rights reserved.
//

import Foundation
import Moya

enum NewsNetworkServices {
    /**
     - **params** in request :
        - country
        - category
        - page
        - pageSize
     - need to add **apiKey** parameter **001b205a82a141fd8e92bb28cf6aa6ae** statically in request which is mandatory
     - page size is set to 4
     **/
    case getNews(country : String, category : String, page : Int)
    /**
     - **params** in request :
     - q : character entered by user in searchBar
        - page
        - pageSize
     - need to add **apiKey** parameter **001b205a82a141fd8e92bb28cf6aa6ae** statically in request which is mandatory
     - page size is set to 10
     **/
    case searchNews(q : String, page : Int)
}

// MARK: TargetType The protocol used to define the specifications necessary for a `MoyaProvider`

extension NewsNetworkServices: TargetType{
    var baseURL: URL {
        return URL(string: "https://newsapi.org/v2/")!
    }
    
    var path: String {
        switch self {
        case .getNews(_):
            return "top-headlines"
        case .searchNews(_):
            return "everything"
        }
    }
    
    var method: Moya.Method {
        return .get
    }
    
    var sampleData: Data {
        return Data()
    }
    
    var task: Task {
        switch self {
        case .getNews(let country,let category,let page):
            return .requestParameters(parameters: ["country": country,"category" : category ,"apiKey" : "ebbd885ace1349919ca0a3d9678c09da", "page" : page, "pageSize" : 4], encoding: URLEncoding.default)
        case .searchNews(let character, let page):
            return .requestParameters(parameters: ["q": character,"sortBy" : "publishedAt", "apiKey": "ebbd885ace1349919ca0a3d9678c09da", "page" : page, "pageSize" : 10], encoding: URLEncoding.default)
        }
    }
    var headers: [String : String]? {
        return nil
    }
}
