//
//  categoryCell.swift
//  NewsFeedAssignment
//
//  Created by Sachin Mann on 21/08/19.
//  Copyright © 2019 Sachin Mann. All rights reserved.
//

import UIKit


class countryCell: UICollectionViewCell {
    
    @IBOutlet weak var textlabel: UILabel!
    override func awakeFromNib() {
        self.layer.cornerRadius = 5
    }
}


class categoryCell: UICollectionViewCell {
    
    @IBOutlet weak var textLabel: UILabel!
    override func awakeFromNib() {
        self.layer.cornerRadius = 5
    }
}
