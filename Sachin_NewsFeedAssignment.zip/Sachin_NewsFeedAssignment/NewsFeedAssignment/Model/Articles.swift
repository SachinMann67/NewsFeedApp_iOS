//
//  Articles.swift
//  NewsFeedAssignment
//
//  Created by CE0009118 on 19/08/19.
//  Copyright © 2019 CE0009118. All rights reserved.
//

import Foundation
