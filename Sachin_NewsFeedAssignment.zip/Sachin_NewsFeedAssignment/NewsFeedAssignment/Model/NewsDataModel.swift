//
//  NewsDataModel.swift
//  NewsFeedAssignment
//
//  Created by CE0009118 on 19/08/19.
//  Copyright © 2019 CE0009118. All rights reserved.
//

import Foundation
struct NewsDataModel : Decodable{
    let status : String
    let totalResults : Int
    let articles : [Articles]?
}

struct Articles : Decodable{
    let source : Source?
    let author,title,description,url,urlToImage,publishedAt,content : String?
}

struct Source : Decodable {
    let id,name : String?
}
